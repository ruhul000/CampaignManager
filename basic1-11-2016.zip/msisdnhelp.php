<?php
    header("Content-Type: text/plain-html");
    header("Content-Disposition: attachment; filename=msisdn.csv;");
    header("Content-Transfer-Encoding:base64");
    echo "919871608913\n";
    echo "919871608912\n";
    echo "919871608914\n";
    echo "919871608915\n";
    echo "919871608916\n";
?>