<?php
$location = "localhost";
$database = "nfmenerg_smsdb";
$username = "nfmenerg_smsu";
$password = "Ag754ffgrtre";

$conn = mysql_connect("$location","$username","$password");
if (!$conn) die ("Could not connect MySQL");

mysql_select_db($database,$conn) or die ("Could not open database");
mysql_query("SET NAMES 'utf8'");
?>
