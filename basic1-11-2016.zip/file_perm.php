<?php
echo 'testing123 folder';
var_dump(is_writable('/opt/'));
/*$structure='./uploads/test';
if (!mkdir($structure, 0, true)) {
    die('Failed to create folders...');
}*/
