<?php
mail('pramod@hosta.loc', 'Cron '.date('d-m-Y H:i:s'), __FILE__);