<?php
echo "Created date is " . date("Y-m-d h:i:sa");

?>